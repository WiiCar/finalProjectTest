package wiicar.carpool.dto;

public class CarpoolDTO {

}
