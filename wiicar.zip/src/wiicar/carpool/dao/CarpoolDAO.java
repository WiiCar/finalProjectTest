package wiicar.carpool.dao;

public interface CarpoolDAO {

}
