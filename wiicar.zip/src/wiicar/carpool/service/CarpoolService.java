package wiicar.carpool.service;

public interface CarpoolService {

}
