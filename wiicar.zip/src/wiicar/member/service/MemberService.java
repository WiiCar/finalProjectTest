package wiicar.member.service;

public interface MemberService {

}
