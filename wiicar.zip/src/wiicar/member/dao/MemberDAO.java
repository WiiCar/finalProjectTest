package wiicar.member.dao;

public interface MemberDAO {

}
