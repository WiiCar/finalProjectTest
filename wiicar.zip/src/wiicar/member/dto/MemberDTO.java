package wiicar.member.dto;

public class MemberDTO {

}
