package wiicar.aop.advice;

public class MemberAspect {

}
