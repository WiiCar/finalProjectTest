package wiicar.aop.advice;

public class AopMemberController {

}
